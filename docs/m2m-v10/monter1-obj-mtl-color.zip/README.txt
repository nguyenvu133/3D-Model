PixiStudio — OBJ + MTL + TEXTURE
================================
OBJ KHONG mang mau trong chinh no. Giu DU 3 thanh phan trong cung thu muc:
  1) monter1_glb.obj
  2) monter1_glb.mtl   (khai bao: newmtl / Kd / map_Kd)
  3) 4 file anh texture: tripo_mat_325368b5-a1fc-4b67-a880-058a38d2e06c_map.jpg, tripo_mat_325368b5-a1fc-4b67-a880-058a38d2e06c_normalMap.png, tripo_mat_325368b5-a1fc-4b67-a880-058a38d2e06c_roughnessMap.jpg, tripo_mat_325368b5-a1fc-4b67-a880-058a38d2e06c_metalnessMap.jpg

Import:
  Blender : File > Import > Wavefront (.obj) -> chon monter1_glb.obj
  Maya    : File > Import -> chon .obj (doc kem .mtl)
  Unity   : keo ca thu muc vao Assets, chon Material > Extract Textures
  Mixamo  : Characters > Upload Character -> FBX (khuyen nghi) hoac ZIP nay

Luu y: doi ten file phai doi theo trong monter1_glb.mtl (dong map_Kd).
Thong tin: 1 mesh, 50000 tam giac, 1 material, 4 anh.
